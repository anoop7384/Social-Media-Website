from django.shortcuts import render,redirect
from django.contrib.auth.decorators import login_required
from .models import Post

# Create your views here.
posts = []


def home(request):
    return redirect('login')


def profile(request):
    context = {
        'title': 'My Posts',
        'posts': ['10 likes','23 likes', '57 likes', '91 likes' ,'123 likes'],
    }
    return render(request, 'connect/profile.html', context)


def create(request):
    return render(request, 'connect/create.html', {'title': 'Create Post'})

@login_required
def posts(request):
    context = {
        'title': 'All Posts',
        'posts': Post.objects.all(),
    }
    return render(request, 'connect/posts.html', context)